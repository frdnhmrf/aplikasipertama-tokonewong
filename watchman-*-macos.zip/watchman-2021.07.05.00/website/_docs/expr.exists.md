---
pageid: expr.exists
title: exists
layout: docs
section: Expression Terms
permalink: docs/expr/exists.html
redirect_from: docs/expr/exists/
---

Evaluates as true if the file exists

    "exists"
    ["exists"]


