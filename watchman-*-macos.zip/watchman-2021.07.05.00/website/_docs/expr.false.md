---
pageid: expr.false
title: "false"
layout: docs
section: Expression Terms
permalink: docs/expr/false.html
redirect_from: docs/expr/false/
---

The `false` expression always evaluates as false.

    "false"
    ["false"]


