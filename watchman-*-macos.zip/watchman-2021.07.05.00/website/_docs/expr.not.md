---
pageid: expr.not
title: not
layout: docs
section: Expression Terms
permalink: docs/expr/not.html
redirect_from: docs/expr/not/
---

The `not` expression inverts the result of the subexpression argument:

    ["not", "empty"]
