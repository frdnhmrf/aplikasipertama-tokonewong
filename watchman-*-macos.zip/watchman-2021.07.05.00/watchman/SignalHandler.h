#pragma once

namespace watchman {

void setup_signal_handlers();

}
