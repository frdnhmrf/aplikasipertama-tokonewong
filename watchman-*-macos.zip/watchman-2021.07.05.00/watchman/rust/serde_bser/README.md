# Work in Progress!

This is work in progress on a BSER implementation that is compatible
with serde.  It is not complete!  If you're reading this and want
to help move it closer to completion, please don't be afraid to
work up a pull request!
