# Copyright (c) 2014-present Facebook. All Rights Reserved.

require 'ruby-watchman/ext'
